import uuid

from django.db import models


class UniqueIds(models.Model):
    class Meta:
        abstract = True

    # primary key with big integer, auto incremented,
    # sequential number, used internally for logic and data management.
    id = models.BigAutoField(primary_key=True, unique=True)

    #  public id to share with the the in url,
    #  Used for REST routes and public displays
    public_id = models.BigIntegerField(editable=False, unique=True)


class PublicId:
    # method for generating public id
    @staticmethod
    def create_public_id():
        public_id = uuid.uuid4().int >> 65
        return public_id
