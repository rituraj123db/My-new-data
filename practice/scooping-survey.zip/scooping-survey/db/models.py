from django.db import models

from .base_models import UniqueIds


class Address(UniqueIds):
    """
    This models class create field into Address models.
    """

    class Meta:
        db_table = "address"

    # VarChar field for property_id
    property_id = models.CharField(max_length=255)

    # VarChar field for device_id
    device_id = models.CharField(max_length=255)
    # VarChar field for company_name
    company_name = models.CharField(max_length=255)

    # VarChar field for user_name
    user_name = models.CharField(max_length=255)

    # VarChar field for address
    address = models.CharField(max_length=255)

    # Integer field for zip_code
    zip_code = models.BigIntegerField()

    # Decimal Field  for latitude
    latitude = models.DecimalField(max_digits=12, decimal_places=9)

    # Decimal Field for longitude
    longitude = models.DecimalField(max_digits=12, decimal_places=9)

    # Varchar Field for  device_type
    device_type = models.CharField(
        choices=([("android", "android"), ("iphone", "iphone")]), max_length=100
    )
    # Date Field for the date
    # date = models.DateTimeField()


class Survey(UniqueIds):
    """
    This models class create field into Survey models.
    """

    class Meta:
        db_table = "survey"

    # Foreign key with table address
    address = models.ForeignKey(
        Address, on_delete=models.CASCADE, related_name="address_related"
    )

    # DateTime field  for date
    date = models.DateTimeField()


class SurveyServiceCategory(UniqueIds):
    """
    This models class create field into SurveyServiceCategory models.
    """

    class Meta:
        db_table = "survey_service_category"

    # Foreign key with table survey
    survey = models.ForeignKey(
        Survey, on_delete=models.CASCADE, related_name="survey_related"
    )

    # VarChar field for service_category
    service_category = models.CharField(max_length=255)


class SurveyService(UniqueIds):
    """
    This models class create field into SurveyService models.
    """

    class Meta:
        db_table = "survey_service"

    # Foreign key with table survey_service_category
    survey_service_category = models.ForeignKey(
        SurveyServiceCategory,
        on_delete=models.CASCADE,
        related_name="survey_service_category",
    )

    # VarChar field for service_name
    service_name = models.CharField(max_length=255)


class SurveyQuestion(UniqueIds):
    """
    This models class create field into SurveyQuestion models.
    """

    class Meta:
        db_table = "survey_question"

    # Foreign key with table survey_service
    survey_service = models.ForeignKey(
        SurveyService, on_delete=models.CASCADE, related_name="survey_service"
    )

    # VarChar field for question
    question = models.CharField(max_length=255)

    # VarChar field for answer
    answer = models.CharField(max_length=255)

    # Decimal field  for price
    price = models.DecimalField(decimal_places=2, default="0.00", max_digits=8)


class SurveyServiceImage(UniqueIds):
    """
    This models class create field into class SurveyServiceImage(UniqueIds):
 models.
    """

    class Meta:
        db_table = "survey_service_image"

    # Foreign key with table survey_question
    survey_question = models.ForeignKey(
        SurveyQuestion, on_delete=models.CASCADE, related_name="survey_question"
    )

    # image field for image_url
    image_url = models.ImageField(upload_to="media/", null=True)
