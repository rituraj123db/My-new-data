# Scooping Survey
