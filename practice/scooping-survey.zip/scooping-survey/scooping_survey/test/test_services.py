from django.test import TestCase
from scooping_survey.services import (
    CreateCategoryService,
    CreateServiceImage,
    CreateServiceQuestion,
    CreateServiceService,
    CreateSurveyServices,
    ScopingSurveyService,
)
from scooping_survey.test.factories import (
    SurveyFactory,
    SurveyQuestionFactory,
    SurveyServiceCategoryFactory,
    SurveyServiceFactory,
)


class ScopingSurveyServiceTest(TestCase):
    """
    This class is used to test create scoping survey services
    """

    def setUp(self):
        self.data = {
            "survey_category": [
                {
                    "id": 1,
                    "name": "Lawn",
                    "services": [
                        {
                            "id": 1,
                            "questions": [
                                {
                                    "answer": "10",
                                    "id": 1,
                                    "images": [
                                        "https://homepages.cae.wisc.edu/~ece533/images/airplane.png",
                                        "https://homepages.cae.wisc.edu/~ece533/images/arctichare.png",
                                        "https://homepages.cae.wisc.edu/~ece533/images/baboon.png",
                                    ],
                                    "price": "43.00",
                                    "question": "How big is the lawn?",
                                },
                                {
                                    "answer": "yes",
                                    "id": 1,
                                    "images": [
                                        "https://homepages.cae.wisc.edu/~ece533/images/airplane.png",
                                        "https://homepages.cae.wisc.edu/~ece533/images/arctichare.png",
                                        "https://homepages.cae.wisc.edu/~ece533/images/baboon.png",
                                    ],
                                    "price": "50.00",
                                    "question": "Does lawn need edging?",
                                },
                                {
                                    "answer": "6-10 inches",
                                    "id": 1,
                                    "images": [
                                        "https://homepages.cae.wisc.edu/~ece533/images/airplane.png",
                                        "https://homepages.cae.wisc.edu/~ece533/images/arctichare.png",
                                        "https://homepages.cae.wisc.edu/~ece533/images/baboon.png",
                                    ],
                                    "price": "43.00",
                                    "question": "How tall is the grass?",
                                },
                            ],
                            "service_category": "Lawn",
                            "service_name": "Mowing/Edging/Overgrowth",
                            "price": "43.00",
                        }
                    ],
                    "price": "43.00",
                },
                {
                    "id": 1,
                    "name": "Flower Beds",
                    "services": [
                        {
                            "id": 1,
                            "questions": [
                                {
                                    "answer": "10",
                                    "id": 8,
                                    "images": [
                                        "https://homepages.cae.wisc.edu/~ece533/images/airplane.png",
                                        "https://homepages.cae.wisc.edu/~ece533/images/arctichare.png",
                                        "https://homepages.cae.wisc.edu/~ece533/images/baboon.png",
                                    ],
                                    "price": "4.40",
                                    "question": "Approximate square footage of flower beds to be weeded?",
                                }
                            ],
                            "service_category": "Garden Beds",
                            "service_name": "Weeding",
                            "price": "4.40",
                        },
                        {
                            "id": 1,
                            "questions": [
                                {
                                    "answer": "11",
                                    "id": 5,
                                    "images": [
                                        "https://homepages.cae.wisc.edu/~ece533/images/airplane.png",
                                        "https://homepages.cae.wisc.edu/~ece533/images/arctichare.png",
                                        "https://homepages.cae.wisc.edu/~ece533/images/baboon.png",
                                    ],
                                    "price": "12.65",
                                    "question": "What is the approximate size of flower beds to be mulched?",
                                },
                                {
                                    "answer": "Black",
                                    "id": 5,
                                    "images": [
                                        "https://homepages.cae.wisc.edu/~ece533/images/airplane.png",
                                        "https://homepages.cae.wisc.edu/~ece533/images/arctichare.png",
                                        "https://homepages.cae.wisc.edu/~ece533/images/baboon.png",
                                    ],
                                    "price": "0",
                                    "question": "What is your desired mulch color?",
                                },
                            ],
                            "service_category": "Garden Beds",
                            "service_name": "Mulch",
                            "price": "12.65",
                        },
                    ],
                    "price": "17.05",
                },
                {
                    "id": 1,
                    "name": "Bushes",
                    "services": [
                        {
                            "id": 1,
                            "questions": [
                                {
                                    "answer": "2",
                                    "id": 4,
                                    "images": [
                                        "https://homepages.cae.wisc.edu/~ece533/images/airplane.png",
                                        "https://homepages.cae.wisc.edu/~ece533/images/arctichare.png",
                                        "https://homepages.cae.wisc.edu/~ece533/images/baboon.png",
                                    ],
                                    "price": "30.00",
                                    "question": "How many bushes, less than six feet tall, need to be trimmed?",
                                }
                            ],
                            "service_category": "Bushes",
                            "service_name": "Bushes",
                            "price": "30.00",
                        }
                    ],
                    "price": "30.00",
                },
                {
                    "id": 1,
                    "name": "Seasonal Cleanup",
                    "services": [
                        {
                            "id": 1,
                            "questions": [
                                {
                                    "answer": "2",
                                    "id": 6,
                                    "images": [
                                        "https://homepages.cae.wisc.edu/~ece533/images/airplane.png",
                                        "https://homepages.cae.wisc.edu/~ece533/images/arctichare.png",
                                        "https://homepages.cae.wisc.edu/~ece533/images/baboon.png",
                                    ],
                                    "price": "84.00",
                                    "question": "How many cubic yards of natural debris (leaves, twigs, etc.) need to "
                                    "be removed? A cubic yard is approximately the size of a washing "
                                    "machine. ",
                                }
                            ],
                            "service_category": "Seasonal Cleanup",
                            "service_name": "Leaf Cleanup",
                            "price": "84.00",
                        }
                    ],
                    "price": "84.00",
                },
                {
                    "id": 1,
                    "name": "Property Exterior",
                    "services": [
                        {
                            "id": 1,
                            "questions": [
                                {
                                    "answer": "2 stories",
                                    "id": 7,
                                    "images": [
                                        "https://homepages.cae.wisc.edu/~ece533/images/airplane.png",
                                        "https://homepages.cae.wisc.edu/~ece533/images/arctichare.png",
                                        "https://homepages.cae.wisc.edu/~ece533/images/baboon.png",
                                    ],
                                    "price": "135",
                                    "question": "How many stories high are the gutters that need clearing?",
                                }
                            ],
                            "service_category": "Property Exterior",
                            "service_name": "Gutters",
                            "price": "135.00",
                        }
                    ],
                    "price": "135.00",
                },
                {
                    "id": 1,
                    "name": "Trees",
                    "services": [
                        {
                            "id": 1,
                            "questions": [
                                {
                                    "answer": "2",
                                    "id": 9,
                                    "images": [
                                        "https://homepages.cae.wisc.edu/~ece533/images/airplane.png",
                                        "https://homepages.cae.wisc.edu/~ece533/images/arctichare.png",
                                        "https://homepages.cae.wisc.edu/~ece533/images/baboon.png",
                                    ],
                                    "price": "0.00",
                                    "question": "Request a bid for tree trimming by entering the information below.",
                                }
                            ],
                            "service_category": "Trees",
                            "service_name": "Tree Trimming",
                            "price": "0.00",
                        }
                    ],
                    "price": "0.00",
                },
            ],
            "survey_info": {
                "address": "4202 Salt Lake Blvd, Honolulu, HI 96818, USA",
                "company_name": "Test Company",
                "date": "2019-11-26 06:41:07",
                "device_type": "Android",
                "latitude": 21.355639,
                "longitude": -157.9257979,
                "user_name": "Krishna",
                "device_id": "f5b83c7fda0c0659",
                "zip_code": "96818",
                "property_id": "testid123456",
            },
        }

    # unit test case of services for scoping service
    def test_scoping_survey(self):
        survey_id = ScopingSurveyService.execute(self.data)
        assert type(survey_id) == int
        assert survey_id is not None

    # unit test case of services for survey service
    def test_survey_service(self):
        survey_info = self.data.get("survey_info")
        survey_info_object = CreateSurveyServices.execute(survey_info)
        assert survey_info_object is not None

    # unit test case of services for category service
    def test_category_service(self):
        survey_obj = SurveyFactory()
        category_service = self.data.get("survey_category")
        category_service_obj = CreateCategoryService.execute(
            {"survey": survey_obj, "survey_category": category_service}
        )

        assert category_service_obj is None

    # unit test case of services for service category services
    def test_service_category(self):
        category_obj = SurveyServiceCategoryFactory()
        categories = self.data.get("survey_category")
        for category in categories:
            service_obj = category.get("services")
        service_obj_data = CreateServiceService.execute(
            {"category": category_obj, "service": service_obj}
        )
        assert service_obj_data is None

    # unit test case of services for survey question service
    def test_survey_question_service(self):
        survey_service_obj = SurveyServiceFactory()
        categories = self.data.get("survey_category")
        for category in categories:
            service_data = category["services"]
            for question in service_data:
                question_data = question.get("questions")
        survey_question_obj = CreateServiceQuestion.execute(
            {"services_service": survey_service_obj, "question": question_data}
        )
        assert survey_question_obj is None

    # unit test case of services for image service
    def test_survey_image_service(self):
        survey_image_obj = SurveyQuestionFactory()
        categories = self.data.get("survey_category")
        for category in categories:
            service_data = category["services"]
            for question in service_data:
                question_data = question.get("questions")
                for images in question_data:
                    images_data = images.get("images")
        images_object = CreateServiceImage.execute(
            {"service_question": survey_image_obj, "image": images_data}
        )
        assert images_object is not None
