import datetime

import factory.fuzzy
from db.base_models import PublicId
from db.models import (
    Address,
    Survey,
    SurveyQuestion,
    SurveyService,
    SurveyServiceCategory,
    SurveyServiceImage,
)
from factory.compat import UTC
from factory.django import DjangoModelFactory


class AddressFactory(DjangoModelFactory):
    """
    This factory class will used to create AddressFactory for Address models.
    """

    class Meta:
        model = Address

    address = factory.fuzzy.FuzzyText(chars="abcdefghijklmnopqrstuvwxyz", length=25)
    company_name = factory.Faker(provider="company")
    device_type = factory.fuzzy.FuzzyChoice(["android"])
    latitude = factory.fuzzy.FuzzyDecimal(19.50139, 64.85694)
    longitude = factory.fuzzy.FuzzyDecimal(-161.75583, -68.01197)
    user_name = factory.Faker(provider="user_name")
    device_id = factory.fuzzy.FuzzyText(chars="abcdefghijklmnopqrstuvwxyz", length=25)
    property_id = factory.fuzzy.FuzzyText(chars="abcdefghijklmnopqrstuvwxyz", length=25)
    public_id = PublicId.create_public_id()
    zip_code = factory.fuzzy.FuzzyInteger(11111, 99999)


class SurveyFactory(DjangoModelFactory):
    """
    This factory class will used to create SurveyFactory for Survey models.
    """

    class Meta:
        model = Survey

    address = factory.SubFactory(AddressFactory)
    date = factory.fuzzy.FuzzyDateTime(datetime.datetime(2008, 1, 1, tzinfo=UTC))
    public_id = PublicId.create_public_id()


class SurveyServiceCategoryFactory(DjangoModelFactory):
    """
    This factory class will used to
    create SurveyServiceCategoryFactory for SurveyServiceCategory models.
    """

    class Meta:
        model = SurveyServiceCategory

    survey = factory.SubFactory(SurveyFactory)
    service_category = factory.fuzzy.FuzzyText()
    public_id = PublicId.create_public_id()


class SurveyServiceFactory(DjangoModelFactory):
    """
    This factory class will used to create
    SurveyServiceImageFactory for SurveyServiceImage models.
    """

    class Meta:
        model = SurveyService

    survey_service_category = factory.SubFactory(SurveyServiceCategoryFactory)
    service_name = factory.fuzzy.FuzzyText(length=255)
    public_id = PublicId.create_public_id()


class SurveyQuestionFactory(DjangoModelFactory):
    """
    This factory class will used to create
    SurveyQuestionFactory for SurveyQuestion models.
    """

    class Meta:
        model = SurveyQuestion

    survey_service = factory.SubFactory(SurveyServiceFactory)
    question = factory.fuzzy.FuzzyText(length=255)
    answer = factory.fuzzy.FuzzyText(length=255)
    price = factory.fuzzy.FuzzyDecimal(1.00, 99999.00)
    public_id = PublicId.create_public_id()


class SurveyServiceImageFactory(DjangoModelFactory):
    """
    This factory class will used to create
    SurveyServiceImageFactory for SurveyServiceImage models.
    """

    class Meta:
        model = SurveyServiceImage

    survey_question = factory.SubFactory(SurveyQuestionFactory)
    image_url = factory.fuzzy.FuzzyText()
    public_id = PublicId.create_public_id()
