from rest_framework import status
from rest_framework.test import APITestCase


class TestCaseForMiddleware(APITestCase):
    """
    This is testing the middleware for wrong URL.
    """

    def test_middle_ware_with_wrong_url(self):
        """
        Unit test case of middleware to check the response with wrong URL.
        :return: Error message with 404 status code.
        """
        url = "wrongUrl"

        response = self.client.get(url)

        # Check status code of response with error message.
        assert response.status_code == status.HTTP_404_NOT_FOUND
        assert response.json()["Error"] == "This url {} not found.".format("/" + url)
