from db.base_models import PublicId
from django.test import TestCase

from .factories import (
    AddressFactory,
    SurveyFactory,
    SurveyQuestionFactory,
    SurveyServiceCategoryFactory,
    SurveyServiceFactory,
    SurveyServiceImageFactory,
)


class CreateAddressTestCase(TestCase):
    """
    This class is used to test create Address models.
    """

    def test_address(self):
        self.public_id = PublicId.create_public_id()
        self.address_data = AddressFactory(public_id=self.public_id)
        assert self.address_data.public_id == self.public_id


class CreateSurveyTestCase(TestCase):
    """
    This class is used to test create Survey models.
    """

    def test_survey(self):
        self.address_data = AddressFactory(
            property_id="testid123456",
            user_name="ravindra",
            address="4202 Salt Lake Blvd, Honolulu, HI 96818, USA",
            latitude=21.355639,
            longitude=-157.9257979,
            zip_code="96818",
            device_id="f5b83c7fda0c0659",
            company_name="taskeasy",
        )
        self.public_id = PublicId.create_public_id()
        survey_data = SurveyFactory(
            public_id=self.public_id, date="2018-10-10", address=self.address_data
        )
        assert survey_data.public_id == self.public_id
        assert survey_data.date == "2018-10-10"
        assert survey_data.address == self.address_data


class CreateSurveyServiceCategoryTestCase(TestCase):
    """
    This class is used to test create SurveyServiceCategory models.
    """

    def test_survey_service_category(self):
        self.public_id = PublicId.create_public_id()
        self.survey_data = SurveyFactory(public_id=self.public_id, date="2018-10-10")
        survey_category_data = SurveyServiceCategoryFactory(
            public_id=self.public_id, survey=self.survey_data
        )

        assert survey_category_data.public_id == self.public_id
        assert survey_category_data.survey == self.survey_data


class CreateSurveyServiceTestCase(TestCase):
    """
    This class is used to test create SurveyService models.
    """

    def test_survey_service(self):
        self.public_id = PublicId.create_public_id()
        self.survey_category_data = SurveyServiceCategoryFactory()
        survey_service_data = SurveyServiceFactory(
            public_id=self.public_id, survey_service_category=self.survey_category_data
        )
        assert survey_service_data.public_id == self.public_id
        assert survey_service_data.survey_service_category == self.survey_category_data


class CreateSurveyQuestionsTestCase(TestCase):
    """
    This class is used to test create SurveyQuestions models.
    """

    def test_survey_question(self):
        self.public_id = PublicId.create_public_id()
        self.survey_service_data = SurveyServiceFactory()
        survey_question_data = SurveyQuestionFactory(
            survey_service=self.survey_service_data,
            public_id=self.public_id,
            price=20.00,
            question="How many bushes, less than six feet tall, " "need to be trimmed?",
            answer="2",
        )
        assert survey_question_data.public_id == self.public_id
        assert survey_question_data.survey_service == self.survey_service_data
        assert (
            survey_question_data.question
            == "How many bushes, less than six feet tall, "
            "need to be trimmed?"
        )
        assert survey_question_data.answer == "2"
        assert survey_question_data.price == 20.00


class CreateSurveyImageServiceTestCase(TestCase):
    """
    This class is used to test create SurveyImageService models.
    """

    def test_image_service(self):
        self.public_id = PublicId.create_public_id()
        self.survey_question_data = SurveyQuestionFactory()
        survey_image_data = SurveyServiceImageFactory(
            public_id=self.public_id,
            survey_question=self.survey_question_data,
            image_url="https://homepages.cae.wisc.edu/~ece533/images" "/airplane.png",
        )
        assert survey_image_data.public_id == self.public_id
        assert survey_image_data.survey_question == self.survey_question_data
        assert (
            survey_image_data.image_url
            == "https://homepages.cae.wisc.edu/~ece533/images/airplane.png"
        )
