from datetime import date

from db.models import (
    Address,
    Survey,
    SurveyQuestion,
    SurveyService,
    SurveyServiceCategory,
    SurveyServiceImage,
)
from django.urls import reverse
from rest_framework import status
from rest_framework.test import APITestCase


class SurveyTests(APITestCase):
    """
    This class is used to API test for end point.
    """

    def setUp(self):
        self.url = reverse("survey")
        self.data = {
            "survey_category": [
                {
                    "id": 1,
                    "name": "Lawn",
                    "services": [
                        {
                            "id": 1,
                            "questions": [
                                {
                                    "answer": "10",
                                    "id": 1,
                                    "images": [
                                        "https://homepages.cae.wisc.edu/~ece533/images/airplane.png",
                                        "https://homepages.cae.wisc.edu/~ece533/images/arctichare.png",
                                        "https://homepages.cae.wisc.edu/~ece533/images/baboon.png",
                                    ],
                                    "price": "43.00",
                                    "question": "How big is the lawn?",
                                },
                                {
                                    "answer": "yes",
                                    "id": 1,
                                    "images": [
                                        "https://homepages.cae.wisc.edu/~ece533/images/airplane.png",
                                        "https://homepages.cae.wisc.edu/~ece533/images/arctichare.png",
                                        "https://homepages.cae.wisc.edu/~ece533/images/baboon.png",
                                    ],
                                    "price": "50.00",
                                    "question": "Does lawn need edging?",
                                },
                                {
                                    "answer": "6-10 inches",
                                    "id": 1,
                                    "images": [
                                        "https://homepages.cae.wisc.edu/~ece533/images/airplane.png",
                                        "https://homepages.cae.wisc.edu/~ece533/images/arctichare.png",
                                        "https://homepages.cae.wisc.edu/~ece533/images/baboon.png",
                                    ],
                                    "price": "43.00",
                                    "question": "How tall is the grass?",
                                },
                            ],
                            "service_category": "Lawn",
                            "service_name": "Mowing/Edging/Overgrowth",
                            "price": "43.00",
                        }
                    ],
                    "price": "43.00",
                },
                {
                    "id": 1,
                    "name": "Flower Beds",
                    "services": [
                        {
                            "id": 1,
                            "questions": [
                                {
                                    "answer": "10",
                                    "id": 8,
                                    "images": [
                                        "https://homepages.cae.wisc.edu/~ece533/images/airplane.png",
                                        "https://homepages.cae.wisc.edu/~ece533/images/arctichare.png",
                                        "https://homepages.cae.wisc.edu/~ece533/images/baboon.png",
                                    ],
                                    "price": "4.40",
                                    "question": "Approximate square footage of flower beds to be weeded?",
                                }
                            ],
                            "service_category": "Garden Beds",
                            "service_name": "Weeding",
                            "price": "4.40",
                        },
                        {
                            "id": 1,
                            "questions": [
                                {
                                    "answer": "11",
                                    "id": 5,
                                    "images": [
                                        "https://homepages.cae.wisc.edu/~ece533/images/airplane.png",
                                        "https://homepages.cae.wisc.edu/~ece533/images/arctichare.png",
                                        "https://homepages.cae.wisc.edu/~ece533/images/baboon.png",
                                    ],
                                    "price": "12.65",
                                    "question": "What is the approximate size of flower beds to be mulched?",
                                },
                                {
                                    "answer": "Black",
                                    "id": 5,
                                    "images": [
                                        "https://homepages.cae.wisc.edu/~ece533/images/airplane.png",
                                        "https://homepages.cae.wisc.edu/~ece533/images/arctichare.png",
                                        "https://homepages.cae.wisc.edu/~ece533/images/baboon.png",
                                    ],
                                    "price": "0",
                                    "question": "What is your desired mulch color?",
                                },
                            ],
                            "service_category": "Garden Beds",
                            "service_name": "Mulch",
                            "price": "12.65",
                        },
                    ],
                    "price": "17.05",
                },
                {
                    "id": 1,
                    "name": "Bushes",
                    "services": [
                        {
                            "id": 1,
                            "questions": [
                                {
                                    "answer": "2",
                                    "id": 4,
                                    "images": [
                                        "https://homepages.cae.wisc.edu/~ece533/images/airplane.png",
                                        "https://homepages.cae.wisc.edu/~ece533/images/arctichare.png",
                                        "https://homepages.cae.wisc.edu/~ece533/images/baboon.png",
                                    ],
                                    "price": "30.00",
                                    "question": "How many bushes, less than six feet tall, need to be trimmed?",
                                }
                            ],
                            "service_category": "Bushes",
                            "service_name": "Bushes",
                            "price": "30.00",
                        }
                    ],
                    "price": "30.00",
                },
                {
                    "id": 1,
                    "name": "Seasonal Cleanup",
                    "services": [
                        {
                            "id": 1,
                            "questions": [
                                {
                                    "answer": "2",
                                    "id": 6,
                                    "images": [
                                        "https://homepages.cae.wisc.edu/~ece533/images/airplane.png",
                                        "https://homepages.cae.wisc.edu/~ece533/images/arctichare.png",
                                        "https://homepages.cae.wisc.edu/~ece533/images/baboon.png",
                                    ],
                                    "price": "84.00",
                                    "question": "How many cubic yards of natural debris (leaves, twigs, etc.) need to "
                                    "be removed? A cubic yard is approximately the size of a washing "
                                    "machine. ",
                                }
                            ],
                            "service_category": "Seasonal Cleanup",
                            "service_name": "Leaf Cleanup",
                            "price": "84.00",
                        }
                    ],
                    "price": "84.00",
                },
                {
                    "id": 1,
                    "name": "Property Exterior",
                    "services": [
                        {
                            "id": 1,
                            "questions": [
                                {
                                    "answer": "2 stories",
                                    "id": 7,
                                    "images": [
                                        "https://homepages.cae.wisc.edu/~ece533/images/airplane.png",
                                        "https://homepages.cae.wisc.edu/~ece533/images/arctichare.png",
                                        "https://homepages.cae.wisc.edu/~ece533/images/baboon.png",
                                    ],
                                    "price": "135",
                                    "question": "How many stories high are the gutters that need clearing?",
                                }
                            ],
                            "service_category": "Property Exterior",
                            "service_name": "Gutters",
                            "price": "135.00",
                        }
                    ],
                    "price": "135.00",
                },
                {
                    "id": 1,
                    "name": "Trees",
                    "services": [
                        {
                            "id": 1,
                            "questions": [
                                {
                                    "answer": "2",
                                    "id": 9,
                                    "images": [
                                        "https://homepages.cae.wisc.edu/~ece533/images/airplane.png",
                                        "https://homepages.cae.wisc.edu/~ece533/images/arctichare.png",
                                        "https://homepages.cae.wisc.edu/~ece533/images/baboon.png",
                                    ],
                                    "price": "0.00",
                                    "question": "Request a bid for tree trimming by entering the information below.",
                                }
                            ],
                            "service_category": "Trees",
                            "service_name": "Tree Trimming",
                            "price": "0.00",
                        }
                    ],
                    "price": "0.00",
                },
            ],
            "survey_info": {
                "address": "4202 Salt Lake Blvd, Honolulu, HI 96818, USA",
                "company_name": "Test Company",
                "date": "2019-11-26 06:41:07",
                "device_type": "Android",
                "latitude": 21.355639,
                "longitude": -157.9257979,
                "user_name": "Krishna",
                "device_id": "f5b83c7fda0c0659",
                "zip_code": "96818",
                "property_id": "testid123456",
            },
        }

    # unit test case for the Models.
    def test_create_models(self):
        response = self.client.post(path=self.url, data=self.data, format="json")
        assert response.status_code == status.HTTP_201_CREATED
        assert Address.objects.all().count() == 1
        assert Survey.objects.all().count() == 1
        assert Survey.objects.get().date.date() == date(2019, 11, 26)
        assert SurveyServiceCategory.objects.all().count() == 6
        assert SurveyService.objects.all().count() == 7
        assert SurveyQuestion.objects.all().count() == 10
        assert SurveyServiceImage.objects.all().count() == 10
