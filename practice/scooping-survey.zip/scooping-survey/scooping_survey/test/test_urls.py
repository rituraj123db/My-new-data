from django.test import TestCase
from django.urls import resolve, reverse
from scooping_survey import views


class UrlTestCase(TestCase):
    """
    Create the UrlTestCase class for test urls
    """

    def test_url_to_view_resolve(self):
        url = reverse("survey")
        response = resolve(url)
        assert response.func.cls == views.SurveyView
