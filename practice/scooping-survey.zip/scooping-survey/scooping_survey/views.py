from rest_framework import status
from rest_framework.response import Response
from rest_framework.views import APIView

from .constants import ERROR_MESSAGE
from .services import ScopingSurveyService


class SurveyView(APIView):
    @staticmethod
    def post(request):
        try:
            survey_id = ScopingSurveyService.execute(request.data)
            if survey_id:
                return Response({"surveyId": survey_id}, status=status.HTTP_201_CREATED)

            return Response(ERROR_MESSAGE, status=status.HTTP_400_BAD_REQUEST)
        except:
            return Response(ERROR_MESSAGE, status=status.HTTP_405_METHOD_NOT_ALLOWED)
