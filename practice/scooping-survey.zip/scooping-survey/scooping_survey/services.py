from db.base_models import PublicId
from db.models import (
    Address,
    Survey,
    SurveyQuestion,
    SurveyService,
    SurveyServiceCategory,
    SurveyServiceImage,
)
from service_objects.services import Service


class CreateSurveyServices(Service):
    """
    This Service class will fetch and
    insert data into Address and Survey models.
    """

    def process(self):
        # fetch data of survey info from survey views.
        survey_info = self.data
        # insert data into Address model.
        address = Address.objects.create(
            public_id=PublicId.create_public_id(),
            device_id=survey_info.get("device_id"),
            property_id=survey_info.get("property_id"),
            company_name=survey_info.get("company_name"),
            user_name=survey_info.get("user_name"),
            address=survey_info.get("address"),
            latitude=survey_info.get("latitude"),
            longitude=survey_info.get("longitude"),
            zip_code=survey_info.get("zip_code"),
            device_type=survey_info.get("device_type"),
        )

        # Insert data into survey table via model.
        survey = Survey.objects.create(
            address=address,
            date=survey_info.get("date"),
            public_id=PublicId.create_public_id(),
        )
        # Return address and survey objects to view.
        return address, survey


class CreateCategoryService(Service):
    """
    This Service class will fetch and insert
    data into SurveyServiceCategory models.
    """

    def process(self):
        # get data from survey views
        post_data = self.data
        survey = post_data.get("survey")
        categories = post_data.get("survey_category")
        # Insert data into SurveyServiceCategory  models.
        for category in categories:
            category_obj = SurveyServiceCategory.objects.create(
                service_category=category.get("name"),
                survey=survey,
                public_id=PublicId.create_public_id(),
            )
            # Pass data to ServiceService from CategoryService class.
            CreateServiceService.execute(
                {"service": category.get("services"), "category": category_obj}
            )


class CreateServiceService(Service):
    """
    This Service class will fetch and insert data into SurveyService models.
    """

    def process(self):
        # Get data from the CategoryService class.
        service_data = self.data
        category_obj = service_data.get("category")
        services = service_data.get("service")

        # Insert data into SurveyService models.
        for service in services:
            services_obj = SurveyService.objects.create(
                service_name=service.get("service_name"),
                survey_service_category=category_obj,
                public_id=PublicId.create_public_id(),
            )

            # Pass data to ServiceQuestion from ServiceService class.
            CreateServiceQuestion.execute(
                {"question": service.get("questions"), "services_service": services_obj}
            )


class CreateServiceQuestion(Service):
    """
    This Service class will fetch and insert data into SurveyService models.
    """

    def process(self):
        # Get data from the ServiceService class.
        question_data = self.data
        questions = question_data.get("question")
        services_service_obj = question_data.get("services_service")
        # Insert data into SurveyQuestion models.
        for quest in questions:
            service_question = SurveyQuestion.objects.create(
                question=quest.get("question"),
                answer=quest.get("answer"),
                price=quest.get("price"),
                public_id=PublicId.create_public_id(),
                survey_service=services_service_obj,
            )

            # Pass data to ServiceQuestion from class ServiceImage class.
            CreateServiceImage.execute(
                {"image": quest.get("images"), "service_question": service_question}
            )


class CreateServiceImage(Service):
    """
    This Service class will fetch and insert
    data into SurveyServiceImage models.
    """

    def process(self):
        # Get the data from ServiceQuestion class.
        image_data = self.data
        images = image_data.get("image")
        service_question_obj = image_data.get("service_question")

        # insert data into SurveyServiceImage models.
        for survey_image in images:
            image_service = SurveyServiceImage.objects.create(
                image_url=survey_image,
                public_id=PublicId.create_public_id(),
                survey_question=service_question_obj,
            )
            # Return the object of image_service.
            return image_service


class ScopingSurveyService(Service):
    """
    This Service class will fetch and
    insert data into CreateCategoryService service.
    """

    def process(self):
        survey_data = self.data
        survey_info = survey_data.get("survey_info")
        address, survey = CreateSurveyServices.execute(survey_info)
        survey_category = survey_data.get("survey_category")

        # Pass data to CreateCategoryService from survey_service class.
        CreateCategoryService.execute(
            {"address": address, "survey": survey, "survey_category": survey_category}
        )
        return survey.public_id
