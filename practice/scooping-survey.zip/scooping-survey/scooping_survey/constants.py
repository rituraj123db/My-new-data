ERROR_MESSAGE = {"error": "went something wrong"}
